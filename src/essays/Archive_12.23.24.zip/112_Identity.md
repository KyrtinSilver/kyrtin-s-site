---
title: "112 - Identity"
layout: essay.njk
date: "2023-12-01"
---

I'm not a consultant, and I'm not going to tell you that everything is going to be alright.

I'm not a teacher, but people who want to learn are welcome to do so.

I value time, mine, and everyone else's.

I value responsibility and actions that live up to it.

I seek to improve the world in tangible, quantifiable, sustainable, enduring, and practical ways.

I seek the knowledge and wisdom of all that may advance this pursuit, every day.

I become more than the sum of these things, and more than I was before.

I become a force to change the world.