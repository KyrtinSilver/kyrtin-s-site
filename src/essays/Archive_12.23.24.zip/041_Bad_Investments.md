---
title: "041 - Bad Investments"
layout: essay.njk
date: "2023-08-17"
---

The world is full of terrible decisions waiting to be made, billions to be burned, and cognitive bias offers abundant and constant temptations.

Once our technology is deployed it will be able to assist with reducing these, but until then bad investments will continue to skew and screw the averages.

#ai #startups #bias #investment #decisionmaking
