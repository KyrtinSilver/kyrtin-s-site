---
title: "050 - Weekend Memes"
layout: essay.njk
date: "2023-08-26"
---

Another Saturday, another 100+ pages of papers to read, some of which I'm peer reviewing.

While my brain cells are occupied with that, here is a collection of some of my favorite more recent AI-related memes. Enjoy your weekend.

![AI Memes](https://pbs.twimg.com/media/GZ4kbAsXIAAIRIg?format=jpg&name=medium)

![AI Memes 2](https://pbs.twimg.com/media/GdQFXrJWgAA8pCX?format=jpg&name=900x900)

![AI Memes 3](https://eldig.psu.edu/wp-content/uploads/2023/09/Untitled.png)

#ai #memes #bias #research
