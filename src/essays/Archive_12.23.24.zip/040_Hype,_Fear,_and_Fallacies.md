---
title: "040 - Hype, Fear, and Fallacies"
layout: essay.njk
date: "2023-08-17"
---

At the heart of much of 2023's Hype and Fearmongering is the concept of "AGI". However, most discussions on the subject are rooted in a collection of false assumptions, fallacies, and fantasies.

Each of these can act as a filter, blocking value being derived from discussion. Many of these stacked together ensure that virtually no value is derived, and all things discussed are no more than vapor.

This is equally true of positive and negative discussion, as Hype and Fearmongering easily form an Ouroboros of mental illness and distraction.

#ai #ethics #bias #AGI #hype
